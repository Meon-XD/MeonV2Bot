const makeWASocket = require("@whiskeysockets/baileys").default;
const { useSingleFileAuthState } = require("@whiskeysockets/baileys");
const { Boom } = require("@hapi/boom");
const P = require("pino");
const fs = require("fs-extra");
const path = require("path");
const chalk = require("chalk");
const figlet = require("figlet");
const moment = require("moment");
const startBot = require("./bot");
const settings = require("./settings.json");

// Membuat folder auth jika belum ada
if (!fs.existsSync('./auth')) {
    fs.mkdirSync('./auth');
}

const { state, saveState } = useSingleFileAuthState(path.join(__dirname, 'auth', 'session.json'));

// Fungsi untuk menampilkan banner
function banner() {
    console.log(chalk.green(figlet.textSync(settings.botName, {
        font: 'Small',
        horizontalLayout: 'default',
        verticalLayout: 'default',
        width: 80,
        whitespaceBreak: false
    })));
    console.log(chalk.cyan('==================================='));
    console.log(chalk.yellow(`Bot Name: ${settings.botName}`));
    console.log(chalk.yellow(`Owner: ${settings.ownerName}`));
    console.log(chalk.yellow(`Prefix: ${settings.prefix}`));
    console.log(chalk.yellow(`Time: ${moment().format('HH:mm:ss')}`));
    console.log(chalk.cyan('==================================='));
}

// Fungsi koneksi bot
async function connectBot() {
    banner();
    
    const sock = makeWASocket({
        logger: P({ level: "silent" }),
        printQRInTerminal: true,
        auth: state,
        browser: [settings.botName, "Chrome", "1.0.0"],
        markOnlineOnConnect: true,
        generateHighQualityLinkPreview: true,
        syncFullHistory: false,
        retryRequestDelayMs: 10,
        connectionTimeoutMs: 30000,
        defaultQueryTimeoutMs: undefined,
        keepAliveIntervalMs: 30000,
        qrTimeout: 60000,
        emitOwnEvents: false,
        patchMessageBeforeSending: (message) => {
            const requiresPatch = !!(
                message.buttonsMessage ||
                message.templateMessage ||
                message.listMessage
            );
            if (requiresPatch) {
                message = {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadataVersion: 2,
                                deviceListMetadata: {},
                            },
                            ...message,
                        },
                    },
                };
            }
            return message;
        }
    });

    // Auto reload bot.js on save
    fs.watchFile(require.resolve("./bot"), () => {
        console.log(chalk.yellow("🔁 bot.js reloaded"));
        delete require.cache[require.resolve("./bot")];
    });

    // Update credentials
    sock.ev.on("creds.update", saveState);

    // Handle connection update
    sock.ev.on("connection.update", (update) => {
        const { connection, lastDisconnect, isNewLogin } = update;
        
        if (connection === "close") {
            const shouldReconnect = (lastDisconnect.error instanceof Boom)?.output?.statusCode !== 401;
            console.log(chalk.red("Connection closed due to "), lastDisconnect.error, ", reconnecting ", shouldReconnect);
            
            if (shouldReconnect) {
                connectBot();
            }
        } else if (connection === "open") {
            console.log(chalk.green("✅ Connected to WhatsApp"));
            
            // Set bot profile
            if (settings.botNumber) {
                sock.updateProfileName(settings.botName).catch(() => {});
            }
        }
    });

    // Handle messages
    sock.ev.on("messages.upsert", async ({ messages }) => {
        if (!messages[0]?.message) return;
        
        const msg = messages[0];
        const from = msg.key.remoteJid;
        const isGroup = from.endsWith("@g.us");
        const sender = isGroup ? msg.key.participant : msg.key.remoteJid;
        
        // Skip messages from self if selfBot is disabled
        if (!settings.selfBot && sender === sock.user.id.split(':')[0] + '@s.whatsapp.net') return;
        
        // Auto read
        if (settings.autoRead) {
            await sock.readMessages([msg.key]);
        }
        
        // Process message
        await startBot(sock, msg);
    });

    // Handle group events
    sock.ev.on("group-participants.update", async (update) => {
        const { id, participants, action } = update;
        
        if (!settings.groupSettings.welcomeMessage && !settings.groupSettings.leaveMessage) return;
        
        const metadata = await sock.groupMetadata(id);
        const groupName = metadata.subject;
        
        for (const participant of participants) {
            const profilePic = await sock.profilePictureUrl(participant, 'image').catch(() => null);
            
            if (action === 'add' && settings.groupSettings.welcomeMessage) {
                const welcomeMessage = `👋 Selamat datang @${participant.split('@')[0]} di grup *${groupName}*!\n\nSemoga betah ya~`;
                await sock.sendMessage(id, {
                    text: welcomeMessage,
                    mentions: [participant]
                });
            } else if (action === 'remove' && settings.groupSettings.leaveMessage) {
                const leaveMessage = `👋 Selamat tinggal @${participant.split('@')[0]} dari grup *${groupName}*!\n\nSemoga kita bertemu lagi~`;
                await sock.sendMessage(id, {
                    text: leaveMessage,
                    mentions: [participant]
                });
            }
        }
    });

    return sock;
}

// Start bot
connectBot().catch(err => {
    console.error(chalk.red("Error starting bot:"), err);
    process.exit(1);
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
    console.error(chalk.red('Uncaught Exception:'), err);
});

process.on('unhandledRejection', (err) => {
    console.error(chalk.red('Unhandled Rejection:'), err);
});