const chalk = require("chalk");
const moment = require("moment");

module.exports = async function(sock, chatInfo, settings) {
    const { from, isGroup, sender } = chatInfo;
    
    // Cek apakah user premium
    const isPremium = settings.premiumUsers.includes(sender.replace('@s.whatsapp.net', '').replace(/[^0-9]/g, ''));
    
    // Menu text
    const menuText = `🤖 *${settings.botName} Menu* 🤖

📅 *Date:* ${moment().format('DD/MM/YYYY')}
⏰ *Time:* ${moment().format('HH:mm:ss')}
👤 *User:* ${isPremium ? '👑 Premium' : '👤 Free'}
🔧 *Prefix:* ${settings.prefix}

┌─「 *GENERAL* 」
│📋 !menu - Menampilkan menu ini
│ℹ️  !info - Informasi bot
│👑 !owner - Kontak owner
│🏓 !ping - Test kecepatan bot
│⏱️  !runtime - Waktu aktif bot
│🚀 !speedtest - Speed test
└─────────────

┌─「 *GROUP* 」
│👥 !tagall - Tag semua member
│⚙️  !group - Menu group
└─────────────

┌─「 *PREMIUM* 」
│➕ !addpremium - Tambah user premium
│➖ !delpremium - Hapus user premium
│📋 !listpremium - Daftar user premium
└─────────────

┌─「 *DOWNLOADER* 」
│🎥 !ytmp4 <link> - Download YouTube Video
│🎵 !ytmp3 <link> - Download YouTube Audio
│🎵 !tiktok <link> - Download TikTok Video
│📹 !facebook <link> - Download Facebook Video
└─────────────

┌─「 *SEARCH* 」
│🔍 !google <query> - Google search
└─────────────

┌─「 *MEDIA* 」
│🎨 !sticker - Buat sticker dari gambar
│🖼️  !toimg - Convert sticker ke image
└─────────────

📝 *Note:*
• Fitur premium hanya bisa digunakan oleh user premium
• Gunakan command dengan benar
• Jangan spam bot!

© ${settings.botName} - ${moment().format('YYYY')}`;
    
    try {
        await sock.sendMessage(from, { 
            text: menuText,
            contextInfo: {
                externalAdReply: {
                    title: settings.botName,
                    body: "WhatsApp Bot by " + settings.ownerName,
                    thumbnailUrl: "https://i.ibb.co/0X1Q6XJ/bot.jpg",
                    sourceUrl: "https://github.com/whiskeybot",
                    mediaType: 1,
                    showAdAttribution: true
                }
            }
        });
    } catch (error) {
        console.error(chalk.red("Error sending menu:"), error);
        await sock.sendMessage(from, { text: "❌ Gagal mengirim menu!" });
    }
};